<?php
/**
 * Plugin Name: AI Chatbot for WooCommerce
 * Plugin URI: https://github.com/yourusername/ai-chatbot
 * Description: AI-powered chatbot that uses your website content to answer customer questions
 * Version: 1.0.0
 * Author: Your Name
 * License: GPL v2 or later
 * Text Domain: ai-chatbot
 * Domain Path: /languages
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * WC requires at least: 7.0
 * WC tested up to: 8.0
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Plugin constants
define('AICB_VERSION', '1.0.0');
define('AICB_PLUGIN_FILE', __FILE__);
define('AICB_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('AICB_PLUGIN_URL', plugin_dir_url(__FILE__));
define('AICB_PLUGIN_BASENAME', plugin_basename(__FILE__));

/**
 * Main plugin class
 */
final class AI_Chatbot {

    /**
     * Single instance
     */
    private static $instance = null;

    /**
     * Get instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor
     */
    private function __construct() {
        $this->load_dependencies();
        $this->set_locale();
        $this->define_admin_hooks();
        $this->define_public_hooks();
        $this->define_sync_hooks();
    }

    /**
     * Load dependencies
     */
    private function load_dependencies() {
        require_once AICB_PLUGIN_DIR . 'includes/class-ai-chatbot-api.php';
        require_once AICB_PLUGIN_DIR . 'includes/class-ai-chatbot-sync.php';
        require_once AICB_PLUGIN_DIR . 'admin/class-ai-chatbot-admin.php';
        require_once AICB_PLUGIN_DIR . 'public/class-ai-chatbot-public.php';
    }

    /**
     * Set plugin locale
     */
    private function set_locale() {
        add_action('plugins_loaded', function() {
            load_plugin_textdomain(
                'ai-chatbot',
                false,
                dirname(AICB_PLUGIN_BASENAME) . '/languages/'
            );
        });
    }

    /**
     * Define admin hooks
     */
    private function define_admin_hooks() {
        $admin = new AI_Chatbot_Admin();

        add_action('admin_menu', array($admin, 'add_admin_menu'));
        add_action('admin_init', array($admin, 'register_settings'));
        add_action('admin_enqueue_scripts', array($admin, 'enqueue_styles'));
        add_action('admin_enqueue_scripts', array($admin, 'enqueue_scripts'));

        // AJAX handlers
        add_action('wp_ajax_aicb_test_connection', array($admin, 'ajax_test_connection'));
        add_action('wp_ajax_aicb_sync_now', array($admin, 'ajax_sync_now'));

        // When settings are saved, optionally sync WooCommerce credentials to backend
        add_action('update_option_aicb_settings', array($admin, 'on_settings_updated'), 10, 3);
    }

    /**
     * Define public hooks
     */
    private function define_public_hooks() {
        $public = new AI_Chatbot_Public();

        add_action('wp_enqueue_scripts', array($public, 'enqueue_styles'));
        add_action('wp_enqueue_scripts', array($public, 'enqueue_scripts'));
    }

    /**
     * Define sync hooks
     */
    private function define_sync_hooks() {
        $sync = new AI_Chatbot_Sync();

        // WooCommerce product hooks
        add_action('woocommerce_update_product', array($sync, 'on_product_update'), 10, 1);
        add_action('woocommerce_new_product', array($sync, 'on_product_update'), 10, 1);
        add_action('before_delete_post', array($sync, 'on_product_delete'), 10, 1);

        // Post/Page hooks
        add_action('save_post_page', array($sync, 'on_page_update'), 10, 3);
        add_action('save_post_post', array($sync, 'on_post_update'), 10, 3);
        add_action('before_delete_post', array($sync, 'on_post_delete'), 10, 1);
    }

    /**
     * Activation hook
     */
    public static function activate() {
        // Set default options
        $defaults = array(
            'enabled' => false,
            'api_url' => '',
            'api_key' => '',
            'bot_name' => 'AI Assistant',
            'welcome_message' => __('Hello! How can I help you today?', 'ai-chatbot'),
            'primary_color' => '#0066FF',
            'position' => 'right',
            'auto_sync' => true,
            'last_sync' => null,
        );

        if (!get_option('aicb_settings')) {
            add_option('aicb_settings', $defaults);
        }

        // Flush rewrite rules
        flush_rewrite_rules();
    }

    /**
     * Deactivation hook
     */
    public static function deactivate() {
        // Clear scheduled events
        wp_clear_scheduled_hook('aicb_scheduled_sync');

        // Flush rewrite rules
        flush_rewrite_rules();
    }
}

// Register activation/deactivation hooks
register_activation_hook(__FILE__, array('AI_Chatbot', 'activate'));
register_deactivation_hook(__FILE__, array('AI_Chatbot', 'deactivate'));

// Initialize plugin
add_action('plugins_loaded', array('AI_Chatbot', 'get_instance'));
