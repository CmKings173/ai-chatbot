<?php
/**
 * Sync functionality
 */

if (!defined('ABSPATH')) {
    exit;
}

class AI_Chatbot_Sync {

    /**
     * API instance
     */
    private $api;

    /**
     * Constructor
     */
    public function __construct() {
        $this->api = new AI_Chatbot_API();
    }

    /**
     * Sync all content
     */
    public function sync_all() {
        $result = array(
            'success' => true,
            'products' => 0,
            'pages' => 0,
            'posts' => 0,
            'errors' => array(),
            'message' => null,
            'async' => true,
        );

        if (!$this->api->is_configured()) {
            $result['success'] = false;
            $result['errors'][] = __('API not configured', 'ai-chatbot');
            return $result;
        }

        // Prefer backend crawl (fast) to avoid WP timeouts/memory issues on large sites
        $rest_api_url = function_exists('get_rest_url')
            ? untrailingslashit(get_rest_url())
            : untrailingslashit(get_site_url(null, '/wp-json'));

        $payload = array(
            'contentTypes' => array('product', 'page', 'post'),
            'force' => true,
            'createEmbeddings' => true,
            'async' => true,
            'restApiUrl' => $rest_api_url,
        );

        $response = $this->api->trigger_crawl($payload);

        if (is_wp_error($response)) {
            $result['success'] = false;
            $result['errors'][] = $response->get_error_message();
            return $result;
        }

        // Update last sync time (represents sync start time)
        $settings = get_option('aicb_settings', array());
        $settings['last_sync'] = current_time('mysql');
        update_option('aicb_settings', $settings);

        $result['message'] = __('Sync started in background. This may take a few minutes.', 'ai-chatbot');

        return $result;
    }

    /**
     * Sync all products
     */
    private function sync_products() {
        $products = wc_get_products(array(
            'status' => 'publish',
            'limit' => -1,
        ));

        $count = 0;
        foreach ($products as $product) {
            $data = $this->build_product_data($product);
            $response = $this->api->send_webhook('/product/update', $data);
            if (!is_wp_error($response)) {
                $count++;
            }
        }

        return array(
            'success' => true,
            'count' => $count,
        );
    }

    /**
     * Sync all pages
     */
    private function sync_pages() {
        $pages = get_posts(array(
            'post_type' => 'page',
            'post_status' => 'publish',
            'numberposts' => -1,
        ));

        $count = 0;
        foreach ($pages as $page) {
            $data = $this->build_post_data($page, 'page');
            $response = $this->api->send_webhook('/post/update', $data);
            if (!is_wp_error($response)) {
                $count++;
            }
        }

        return array(
            'success' => true,
            'count' => $count,
        );
    }

    /**
     * Sync all posts
     */
    private function sync_posts() {
        $posts = get_posts(array(
            'post_type' => 'post',
            'post_status' => 'publish',
            'numberposts' => -1,
        ));

        $count = 0;
        foreach ($posts as $post) {
            $data = $this->build_post_data($post, 'post');
            $response = $this->api->send_webhook('/post/update', $data);
            if (!is_wp_error($response)) {
                $count++;
            }
        }

        return array(
            'success' => true,
            'count' => $count,
        );
    }

    /**
     * Build product data for API
     */
    private function build_product_data($product) {
        $content = $product->get_description();
        $short_desc = $product->get_short_description();
        if ($short_desc) {
            $content = $short_desc . "\n\n" . $content;
        }

        // Get sale price if on sale
        $price = $product->get_regular_price();
        $sale_price = $product->get_sale_price();

        return array(
            'sourceId' => (string) $product->get_id(),
            'title' => $product->get_name(),
            'content' => $content,
            'metadata' => array(
                'url' => $product->get_permalink(),
                'price' => floatval($price),
                'salePrice' => $sale_price ? floatval($sale_price) : null,
                'sku' => $product->get_sku(),
                'stockStatus' => $product->get_stock_status(),
                'categories' => wp_get_post_terms(
                    $product->get_id(),
                    'product_cat',
                    array('fields' => 'names')
                ),
                'tags' => wp_get_post_terms(
                    $product->get_id(),
                    'product_tag',
                    array('fields' => 'names')
                ),
                'imageUrl' => wp_get_attachment_url($product->get_image_id()),
            ),
        );
    }

    /**
     * Build post/page data for API
     */
    private function build_post_data($post, $type = 'post') {
        $categories = array();
        $tags = array();

        if ($type === 'post') {
            $categories = wp_get_post_terms($post->ID, 'category', array('fields' => 'names'));
            $tags = wp_get_post_terms($post->ID, 'post_tag', array('fields' => 'names'));
        }

        $thumbnail_id = get_post_thumbnail_id($post->ID);
        $image_url = $thumbnail_id ? wp_get_attachment_url($thumbnail_id) : null;

        return array(
            'sourceId' => (string) $post->ID,
            'sourceType' => $type,
            'title' => $post->post_title,
            'content' => $post->post_content,
            'metadata' => array(
                'url' => get_permalink($post->ID),
                'categories' => $categories ?: null,
                'tags' => $tags ?: null,
                'imageUrl' => $image_url,
                'excerpt' => $post->post_excerpt ?: null,
            ),
        );
    }

    /**
     * Handle product update
     */
    public function on_product_update($product_id) {
        $settings = get_option('aicb_settings', array());
        if (empty($settings['auto_sync']) || empty($settings['api_url'])) {
            return;
        }

        $product = wc_get_product($product_id);
        if (!$product || $product->get_status() !== 'publish') {
            return;
        }

        $data = $this->build_product_data($product);
        $this->api->send_webhook('/product/update', $data);
    }

    /**
     * Handle product delete
     */
    public function on_product_delete($post_id) {
        if (get_post_type($post_id) !== 'product') {
            return;
        }

        $settings = get_option('aicb_settings', array());
        if (empty($settings['auto_sync']) || empty($settings['api_url'])) {
            return;
        }

        $this->api->send_webhook('/product/delete', array(
            'sourceId' => (string) $post_id,
        ));
    }

    /**
     * Handle page update
     */
    public function on_page_update($post_id, $post, $update) {
        if ($post->post_status !== 'publish') {
            return;
        }

        $settings = get_option('aicb_settings', array());
        if (empty($settings['auto_sync']) || empty($settings['api_url'])) {
            return;
        }

        $data = $this->build_post_data($post, 'page');
        $this->api->send_webhook('/post/update', $data);
    }

    /**
     * Handle post update
     */
    public function on_post_update($post_id, $post, $update) {
        if ($post->post_status !== 'publish') {
            return;
        }

        $settings = get_option('aicb_settings', array());
        if (empty($settings['auto_sync']) || empty($settings['api_url'])) {
            return;
        }

        $data = $this->build_post_data($post, 'post');
        $this->api->send_webhook('/post/update', $data);
    }

    /**
     * Handle post/page delete
     */
    public function on_post_delete($post_id) {
        $post_type = get_post_type($post_id);
        if (!in_array($post_type, array('page', 'post'))) {
            return;
        }

        $settings = get_option('aicb_settings', array());
        if (empty($settings['auto_sync']) || empty($settings['api_url'])) {
            return;
        }

        $this->api->send_webhook('/post/delete', array(
            'sourceId' => (string) $post_id,
            'sourceType' => $post_type,
        ));
    }
}
