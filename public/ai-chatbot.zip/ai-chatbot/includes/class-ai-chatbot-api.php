<?php
/**
 * API communication class
 */

if (!defined('ABSPATH')) {
    exit;
}

class AI_Chatbot_API {

    /**
     * API URL
     */
    private $api_url;

    /**
     * API Key
     */
    private $api_key;

    /**
     * Constructor
     */
    public function __construct() {
        $settings = get_option('aicb_settings', array());
        $this->api_url = rtrim($settings['api_url'] ?? '', '/');
        $this->api_key = $settings['api_key'] ?? '';
    }

    /**
     * Make API request
     */
    public function request($endpoint, $method = 'GET', $body = null) {
        if (empty($this->api_url) || empty($this->api_key)) {
            return new WP_Error('api_not_configured', __('API not configured', 'ai-chatbot'));
        }

        $args = array(
            'method' => $method,
            'timeout' => 30,
            'headers' => array(
                'Content-Type' => 'application/json',
                'X-API-Key' => $this->api_key,
            ),
        );

        if ($body !== null) {
            $args['body'] = wp_json_encode($body);
        }

        $url = $this->api_url . $endpoint;
        $response = wp_remote_request($url, $args);

        if (is_wp_error($response)) {
            return $response;
        }

        $code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        if ($code >= 400) {
            $message = isset($data['message']) ? $data['message'] : __('API error', 'ai-chatbot');
            return new WP_Error('api_error', $message, array('status' => $code));
        }

        return $data;
    }

    /**
     * Test connection
     */
    public function test_connection() {
        // Use backend auth verification endpoint to validate API key
        $response = $this->request('/api/auth/verify', 'GET');
        return !is_wp_error($response);
    }

    /**
     * Send webhook
     */
    public function send_webhook($endpoint, $data) {
        return $this->request('/webhook' . $endpoint, 'POST', $data);
    }

    /**
     * Trigger crawl
     */
    public function trigger_crawl($data) {
        return $this->request('/api/crawler/sync', 'POST', $data);
    }

    /**
     * Update current site's WordPress credentials in backend
     */
    public function update_wordpress_credentials($rest_api_url, $consumer_key, $consumer_secret) {
        $payload = array(
            'wordpressCredentials' => array(
                'restApiUrl' => $rest_api_url,
                'consumerKey' => $consumer_key,
                'consumerSecret' => $consumer_secret,
            ),
        );

        return $this->request('/api/sites/me', 'PATCH', $payload);
    }

    /**
     * Check if API is configured
     */
    public function is_configured() {
        return !empty($this->api_url) && !empty($this->api_key);
    }
}
