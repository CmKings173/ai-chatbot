<?php
/**
 * Public-facing functionality
 */

if (!defined('ABSPATH')) {
    exit;
}

class AI_Chatbot_Public {

    /**
     * Enqueue public styles
     */
    public function enqueue_styles() {
        $settings = get_option('aicb_settings', array());

        if (empty($settings['enabled']) || empty($settings['api_url'])) {
            return;
        }

        wp_enqueue_style(
            'aicb-chatbox',
            AICB_PLUGIN_URL . 'public/css/chatbox.min.css',
            array(),
            AICB_VERSION
        );
    }

    /**
     * Enqueue public scripts
     */
    public function enqueue_scripts() {
        $settings = get_option('aicb_settings', array());

        if (empty($settings['enabled']) || empty($settings['api_url'])) {
            return;
        }

        // Enqueue the chatbox script
        wp_enqueue_script(
            'aicb-chatbox',
            AICB_PLUGIN_URL . 'public/js/chatbox.min.js',
            array(),
            AICB_VERSION,
            true
        );

        // Provide configuration to the widget
        wp_localize_script('aicb-chatbox', 'WPAIChatboxConfig', array(
            'apiKey' => $settings['api_key'],
            'apiUrl' => rtrim($settings['api_url'], '/'),
            'botName' => $settings['bot_name'] ?? 'AI Assistant',
            'welcomeMessage' => $settings['welcome_message'] ?? __('Hello! How can I help you today?', 'ai-chatbot'),
            'primaryColor' => $settings['primary_color'] ?? '#0066FF',
            'position' => $settings['position'] ?? 'right',
            'placeholder' => __('Type your message...', 'ai-chatbot'),
        ));
    }
}
