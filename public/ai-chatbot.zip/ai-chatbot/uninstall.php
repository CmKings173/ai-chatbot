<?php
/**
 * Uninstall script
 *
 * This file is executed when the plugin is deleted via WordPress admin.
 * It removes all plugin data from the database.
 */

// Exit if not uninstalling
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Remove plugin options
delete_option('aicb_settings');

// Remove any transients
delete_transient('aicb_connection_status');

// Clear any scheduled events
wp_clear_scheduled_hook('aicb_scheduled_sync');
