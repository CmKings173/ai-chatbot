<?php
/**
 * Admin settings page template
 */

if (!defined('ABSPATH')) {
    exit;
}

$settings = get_option('aicb_settings', array());
?>

<div class="wrap aicb-admin">
    <h1><?php echo esc_html(get_admin_page_title()); ?></h1>

    <?php
    $wc_notice = get_transient('aicb_wc_credentials_notice');
    if (!empty($wc_notice) && is_array($wc_notice) && !empty($wc_notice['message'])) {
        $type = ($wc_notice['type'] ?? 'success') === 'error' ? 'error' : 'success';
        $class = $type === 'error' ? 'notice notice-error is-dismissible' : 'notice notice-success is-dismissible';
        echo '<div class="' . esc_attr($class) . '"><p>' . esc_html($wc_notice['message']) . '</p></div>';
        delete_transient('aicb_wc_credentials_notice');
    }
    ?>

    <form method="post" action="options.php">
        <?php settings_fields('aicb_settings_group'); ?>

        <!-- Enable/Disable -->
        <div class="aicb-card">
            <h2><?php esc_html_e('Status', 'ai-chatbot'); ?></h2>
            <table class="form-table">
                <tr>
                    <th scope="row"><?php esc_html_e('Enable Chatbot', 'ai-chatbot'); ?></th>
                    <td>
                        <label class="aicb-toggle">
                            <input type="checkbox"
                                   name="aicb_settings[enabled]"
                                   value="1"
                                   <?php checked(!empty($settings['enabled'])); ?>>
                            <span class="aicb-toggle-slider"></span>
                        </label>
                        <p class="description">
                            <?php esc_html_e('Show the chatbot widget on your website', 'ai-chatbot'); ?>
                        </p>
                    </td>
                </tr>
            </table>
        </div>

        <!-- API Configuration -->
        <div class="aicb-card">
            <h2><?php esc_html_e('API Configuration', 'ai-chatbot'); ?></h2>
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="aicb_api_url"><?php esc_html_e('API URL', 'ai-chatbot'); ?></label>
                    </th>
                    <td>
                        <input type="url"
                               id="aicb_api_url"
                               name="aicb_settings[api_url]"
                               value="<?php echo esc_attr($settings['api_url'] ?? ''); ?>"
                               class="regular-text"
                               placeholder="https://api.example.com"
                               required>
                        <p class="description">
                            <?php esc_html_e('Base URL of your AI Chatbot backend (do not include /api)', 'ai-chatbot'); ?>
                        </p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="aicb_api_key"><?php esc_html_e('API Key', 'ai-chatbot'); ?></label>
                    </th>
                    <td>
                        <input type="text"
                               id="aicb_api_key"
                               name="aicb_settings[api_key]"
                               value="<?php echo esc_attr($settings['api_key'] ?? ''); ?>"
                               class="regular-text"
                               required>
                        <button type="button" id="aicb-test-connection" class="button">
                            <?php esc_html_e('Test Connection', 'ai-chatbot'); ?>
                        </button>
                        <span id="aicb-connection-status"></span>
                        <p class="description">
                            <?php esc_html_e('Your API key from the AI Chatbot dashboard', 'ai-chatbot'); ?>
                        </p>
                    </td>
                </tr>
            </table>
        </div>

        <!-- Widget Appearance -->
        <div class="aicb-card">
            <h2><?php esc_html_e('Widget Appearance', 'ai-chatbot'); ?></h2>
            <table class="form-table">
                <tr>
                    <th scope="row">
                        <label for="aicb_bot_name"><?php esc_html_e('Bot Name', 'ai-chatbot'); ?></label>
                    </th>
                    <td>
                        <input type="text"
                               id="aicb_bot_name"
                               name="aicb_settings[bot_name]"
                               value="<?php echo esc_attr($settings['bot_name'] ?? 'AI Assistant'); ?>"
                               class="regular-text">
                        <p class="description">
                            <?php esc_html_e('The name shown in the chat header', 'ai-chatbot'); ?>
                        </p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="aicb_welcome_message"><?php esc_html_e('Welcome Message', 'ai-chatbot'); ?></label>
                    </th>
                    <td>
                        <textarea id="aicb_welcome_message"
                                  name="aicb_settings[welcome_message]"
                                  rows="3"
                                  class="large-text"><?php echo esc_textarea($settings['welcome_message'] ?? ''); ?></textarea>
                        <p class="description">
                            <?php esc_html_e('The first message shown when a user opens the chat', 'ai-chatbot'); ?>
                        </p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="aicb_primary_color"><?php esc_html_e('Primary Color', 'ai-chatbot'); ?></label>
                    </th>
                    <td>
                        <input type="text"
                               id="aicb_primary_color"
                               name="aicb_settings[primary_color]"
                               value="<?php echo esc_attr($settings['primary_color'] ?? '#0066FF'); ?>"
                               class="aicb-color-picker">
                        <p class="description">
                            <?php esc_html_e('The main color for the chat button and header', 'ai-chatbot'); ?>
                        </p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><?php esc_html_e('Position', 'ai-chatbot'); ?></th>
                    <td>
                        <fieldset>
                            <label>
                                <input type="radio"
                                       name="aicb_settings[position]"
                                       value="right"
                                       <?php checked(($settings['position'] ?? 'right'), 'right'); ?>>
                                <?php esc_html_e('Bottom Right', 'ai-chatbot'); ?>
                            </label>
                            <br>
                            <label>
                                <input type="radio"
                                       name="aicb_settings[position]"
                                       value="left"
                                       <?php checked(($settings['position'] ?? 'right'), 'left'); ?>>
                                <?php esc_html_e('Bottom Left', 'ai-chatbot'); ?>
                            </label>
                        </fieldset>
                    </td>
                </tr>
            </table>
        </div>

        <!-- Sync Settings -->
        <div class="aicb-card">
            <h2><?php esc_html_e('Content Sync', 'ai-chatbot'); ?></h2>
            <table class="form-table">
                <tr>
                    <th scope="row"><?php esc_html_e('Auto Sync', 'ai-chatbot'); ?></th>
                    <td>
                        <label class="aicb-toggle">
                            <input type="checkbox"
                                   name="aicb_settings[auto_sync]"
                                   value="1"
                                   <?php checked(!empty($settings['auto_sync'])); ?>>
                            <span class="aicb-toggle-slider"></span>
                        </label>
                        <p class="description">
                            <?php esc_html_e('Automatically sync content when products, pages, or posts are updated', 'ai-chatbot'); ?>
                        </p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="aicb_wc_consumer_key"><?php esc_html_e('WooCommerce Consumer Key', 'ai-chatbot'); ?></label>
                    </th>
                    <td>
                        <input type="text"
                               id="aicb_wc_consumer_key"
                               name="aicb_settings[wc_consumer_key]"
                               value="<?php echo esc_attr($settings['wc_consumer_key'] ?? ''); ?>"
                               class="regular-text"
                               autocomplete="off"
                               placeholder="ck_...">
                        <p class="description">
                            <?php esc_html_e('Optional. Used by the backend to crawl WooCommerce products and shipping settings (zones/methods). Create it in WooCommerce → Settings → Advanced → REST API.', 'ai-chatbot'); ?>
                        </p>
                    </td>
                </tr>
                <tr>
                    <th scope="row">
                        <label for="aicb_wc_consumer_secret"><?php esc_html_e('WooCommerce Consumer Secret', 'ai-chatbot'); ?></label>
                    </th>
                    <td>
                        <input type="password"
                               id="aicb_wc_consumer_secret"
                               name="aicb_settings[wc_consumer_secret]"
                               value=""
                               class="regular-text"
                               autocomplete="new-password"
                               placeholder="cs_...">
                        <?php if (!empty($settings['wc_consumer_secret'])) : ?>
                            <p class="description">
                                <?php esc_html_e('A secret is already saved. Leave blank to keep the existing value.', 'ai-chatbot'); ?>
                            </p>
                        <?php else : ?>
                            <p class="description">
                                <?php esc_html_e('Optional. Enter the consumer secret to enable product/shipping sync. Leave blank if you only want pages/posts.', 'ai-chatbot'); ?>
                            </p>
                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><?php esc_html_e('Manual Sync', 'ai-chatbot'); ?></th>
                    <td>
                        <button type="button" id="aicb-sync-now" class="button button-secondary">
                            <?php esc_html_e('Sync Now', 'ai-chatbot'); ?>
                        </button>
                        <span id="aicb-sync-status"></span>
                        <p class="description">
                            <?php
                            if (!empty($settings['last_sync'])) {
                                printf(
                                    esc_html__('Last synced: %s', 'ai-chatbot'),
                                    esc_html(wp_date(get_option('date_format') . ' ' . get_option('time_format'), strtotime($settings['last_sync'])))
                                );
                            } else {
                                esc_html_e('Never synced', 'ai-chatbot');
                            }
                            ?>
                        </p>
                    </td>
                </tr>
            </table>
        </div>

        <?php submit_button(__('Save Settings', 'ai-chatbot')); ?>
    </form>
</div>
