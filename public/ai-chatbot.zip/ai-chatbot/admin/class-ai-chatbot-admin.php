<?php
/**
 * Admin functionality
 */

if (!defined('ABSPATH')) {
    exit;
}

class AI_Chatbot_Admin {

    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        add_menu_page(
            __('AI Chatbot', 'ai-chatbot'),
            __('AI Chatbot', 'ai-chatbot'),
            'manage_options',
            'ai-chatbot',
            array($this, 'render_settings_page'),
            'dashicons-format-chat',
            30
        );
    }

    /**
     * Register settings
     */
    public function register_settings() {
        register_setting(
            'aicb_settings_group',
            'aicb_settings',
            array(
                'type' => 'array',
                'sanitize_callback' => array($this, 'sanitize_settings'),
            )
        );
    }

    /**
     * Sanitize settings
     */
    public function sanitize_settings($input) {
        $sanitized = array();

        $sanitized['enabled'] = !empty($input['enabled']);
        $sanitized['api_url'] = esc_url_raw(rtrim($input['api_url'] ?? '', '/'));
        $sanitized['api_key'] = sanitize_text_field($input['api_key'] ?? '');
        $sanitized['bot_name'] = sanitize_text_field($input['bot_name'] ?? 'AI Assistant');
        $sanitized['welcome_message'] = sanitize_textarea_field($input['welcome_message'] ?? '');
        $sanitized['primary_color'] = sanitize_hex_color($input['primary_color'] ?? '#0066FF');
        $sanitized['position'] = in_array($input['position'] ?? 'right', array('left', 'right'))
            ? $input['position'] : 'right';
        $sanitized['auto_sync'] = !empty($input['auto_sync']);

        // Preserve last sync time + sensitive fields
        $current = get_option('aicb_settings', array());
        $sanitized['last_sync'] = $current['last_sync'] ?? null;

        // Optional: WooCommerce REST API keys (for products + shipping settings crawl)
        $sanitized['wc_consumer_key'] = sanitize_text_field($input['wc_consumer_key'] ?? '');

        // Preserve secret if left blank on save
        $consumer_secret = sanitize_text_field($input['wc_consumer_secret'] ?? '');
        if (empty($consumer_secret) && !empty($current['wc_consumer_secret'])) {
            $consumer_secret = $current['wc_consumer_secret'];
        }
        $sanitized['wc_consumer_secret'] = $consumer_secret;

        return $sanitized;
    }

    /**
     * Enqueue admin styles
     */
    public function enqueue_styles($hook) {
        if ('toplevel_page_ai-chatbot' !== $hook) {
            return;
        }

        wp_enqueue_style(
            'aicb-admin',
            AICB_PLUGIN_URL . 'admin/css/ai-chatbot-admin.css',
            array(),
            AICB_VERSION
        );

        wp_enqueue_style('wp-color-picker');
    }

    /**
     * Enqueue admin scripts
     */
    public function enqueue_scripts($hook) {
        if ('toplevel_page_ai-chatbot' !== $hook) {
            return;
        }

        wp_enqueue_script(
            'aicb-admin',
            AICB_PLUGIN_URL . 'admin/js/ai-chatbot-admin.js',
            array('jquery', 'wp-color-picker'),
            AICB_VERSION,
            true
        );

        wp_localize_script('aicb-admin', 'aicbAdmin', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('aicb_admin_nonce'),
            'strings' => array(
                'testing' => __('Testing...', 'ai-chatbot'),
                'testConnection' => __('Test Connection', 'ai-chatbot'),
                'syncing' => __('Syncing...', 'ai-chatbot'),
                'syncNow' => __('Sync Now', 'ai-chatbot'),
                'connectionSuccess' => __('Connection successful!', 'ai-chatbot'),
                'connectionFailed' => __('Connection failed:', 'ai-chatbot'),
                'syncSuccess' => __('Sync completed!', 'ai-chatbot'),
                'syncFailed' => __('Sync failed:', 'ai-chatbot'),
            ),
        ));
    }

    /**
     * Render settings page
     */
    public function render_settings_page() {
        include AICB_PLUGIN_DIR . 'admin/partials/ai-chatbot-settings.php';
    }

    /**
     * AJAX: Test connection
     */
    public function ajax_test_connection() {
        check_ajax_referer('aicb_admin_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Permission denied', 'ai-chatbot'));
        }

        $api = new AI_Chatbot_API();

        if (!$api->is_configured()) {
            wp_send_json_error(__('Please save API settings first', 'ai-chatbot'));
        }

        if ($api->test_connection()) {
            wp_send_json_success(__('Connection successful!', 'ai-chatbot'));
        } else {
            wp_send_json_error(__('Connection failed. Please check your API URL and key.', 'ai-chatbot'));
        }
    }

    /**
     * AJAX: Sync now
     */
    public function ajax_sync_now() {
        check_ajax_referer('aicb_admin_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(__('Permission denied', 'ai-chatbot'));
        }

        $sync = new AI_Chatbot_Sync();
        $result = $sync->sync_all();

        if ($result['success']) {
            $message = !empty($result['message'])
                ? $result['message']
                : sprintf(
                    __('Sync completed! Products: %d, Pages: %d, Posts: %d', 'ai-chatbot'),
                    $result['products'],
                    $result['pages'],
                    $result['posts']
                );

            wp_send_json_success(array(
                'message' => $message,
                'products' => $result['products'],
                'pages' => $result['pages'],
                'posts' => $result['posts'],
                'async' => !empty($result['async']),
            ));
        } else {
            wp_send_json_error(implode(', ', $result['errors']));
        }
    }

    /**
     * When settings are saved, optionally sync WooCommerce credentials to backend.
     * This enables the backend crawler to fetch products + shipping settings via WooCommerce REST API.
     */
    public function on_settings_updated($old_value, $value, $option_name) {
        if ($option_name !== 'aicb_settings') {
            return;
        }

        if (!is_array($value)) {
            return;
        }

        $api_url = $value['api_url'] ?? '';
        $api_key = $value['api_key'] ?? '';

        if (empty($api_url) || empty($api_key)) {
            return;
        }

        $consumer_key = $value['wc_consumer_key'] ?? '';
        $consumer_secret = $value['wc_consumer_secret'] ?? '';

        // Nothing to sync
        if (empty($consumer_key) && empty($consumer_secret)) {
            return;
        }

        // Incomplete credentials
        if (empty($consumer_key) || empty($consumer_secret)) {
            set_transient('aicb_wc_credentials_notice', array(
                'type' => 'error',
                'message' => __('Please provide both WooCommerce Consumer Key and Consumer Secret to enable product/shipping sync.', 'ai-chatbot'),
            ), 60);
            return;
        }

        $rest_api_url = function_exists('get_rest_url')
            ? untrailingslashit(get_rest_url())
            : untrailingslashit(get_site_url(null, '/wp-json'));

        $api = new AI_Chatbot_API();
        $response = $api->update_wordpress_credentials($rest_api_url, $consumer_key, $consumer_secret);

        if (is_wp_error($response)) {
            set_transient('aicb_wc_credentials_notice', array(
                'type' => 'error',
                'message' => __('Failed to sync WooCommerce credentials to backend: ', 'ai-chatbot') . $response->get_error_message(),
            ), 60);
            return;
        }

        set_transient('aicb_wc_credentials_notice', array(
            'type' => 'success',
            'message' => __('WooCommerce credentials synced to backend.', 'ai-chatbot'),
        ), 60);
    }
}
