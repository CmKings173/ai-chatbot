/**
 * Admin JavaScript
 */
(function($) {
    'use strict';

    $(document).ready(function() {
        // Initialize color picker
        if ($.fn.wpColorPicker) {
            $('.aicb-color-picker').wpColorPicker();
        }

        // Test Connection
        $('#aicb-test-connection').on('click', function() {
            var $btn = $(this);
            var $status = $('#aicb-connection-status');

            $btn.prop('disabled', true).text(aicbAdmin.strings.testing);
            $status.removeClass('success error').text('');

            $.ajax({
                url: aicbAdmin.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'aicb_test_connection',
                    nonce: aicbAdmin.nonce
                },
                success: function(response) {
                    if (response.success) {
                        $status.addClass('success').text(response.data);
                    } else {
                        $status.addClass('error').text(aicbAdmin.strings.connectionFailed + ' ' + response.data);
                    }
                },
                error: function() {
                    $status.addClass('error').text(aicbAdmin.strings.connectionFailed + ' Network error');
                },
                complete: function() {
                    $btn.prop('disabled', false).text(aicbAdmin.strings.testConnection);
                }
            });
        });

        // Sync Now
        $('#aicb-sync-now').on('click', function() {
            var $btn = $(this);
            var $status = $('#aicb-sync-status');

            if (!confirm('This will sync all your content to the AI backend. Continue?')) {
                return;
            }

            $btn.prop('disabled', true).text(aicbAdmin.strings.syncing);
            $status.removeClass('success error').text('');

            $.ajax({
                url: aicbAdmin.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'aicb_sync_now',
                    nonce: aicbAdmin.nonce
                },
                success: function(response) {
                    if (response.success) {
                        $status.addClass('success').text(response.data.message);
                        // Reload to update last sync time
                        setTimeout(function() {
                            location.reload();
                        }, 2000);
                    } else {
                        $status.addClass('error').text(aicbAdmin.strings.syncFailed + ' ' + response.data);
                    }
                },
                error: function() {
                    $status.addClass('error').text(aicbAdmin.strings.syncFailed + ' Network error');
                },
                complete: function() {
                    $btn.prop('disabled', false).text(aicbAdmin.strings.syncNow);
                }
            });
        });
    });
})(jQuery);
