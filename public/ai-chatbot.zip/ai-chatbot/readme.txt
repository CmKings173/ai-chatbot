=== AI Chatbot for WooCommerce ===
Contributors: yourname
Tags: chatbot, ai, woocommerce, customer service, chat
Requires at least: 6.0
Tested up to: 6.4
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

AI-powered chatbot that uses your website content to answer customer questions.

== Description ==

AI Chatbot for WooCommerce is an intelligent chat widget that learns from your website content (products, pages, posts) to provide accurate answers to customer questions.

= Features =

* **AI-Powered Responses**: Uses advanced AI to understand and answer customer questions
* **Content Sync**: Automatically syncs your WooCommerce products, pages, and posts
* **Real-time Chat**: WebSocket-based instant messaging
* **Customizable Widget**: Change colors, position, welcome message, and bot name
* **Auto-Sync**: Automatically updates when content changes
* **Easy Setup**: Simple configuration with API URL and key

= Requirements =

* WordPress 6.0 or higher
* PHP 7.4 or higher
* WooCommerce 7.0 or higher (optional, for product sync)
* An AI Chatbot backend server

== Installation ==

1. Upload the plugin files to `/wp-content/plugins/ai-chatbot/`
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to 'AI Chatbot' in the admin menu
4. Enter your API URL and API Key
5. Click 'Test Connection' to verify
6. Enable the chatbot and save settings

== Frequently Asked Questions ==

= Where do I get an API key? =

You need to set up the AI Chatbot backend server and generate an API key for your WordPress site.

= Does it work without WooCommerce? =

Yes, the chatbot will sync your pages and posts even without WooCommerce. Product sync requires WooCommerce.

= Can I customize the chat widget appearance? =

Yes, you can change the primary color, position (left/right), bot name, and welcome message from the settings page.

== Screenshots ==

1. Chat widget on your website
2. Admin settings page
3. Sync configuration

== Changelog ==

= 1.0.0 =
* Initial release
* Product, page, and post sync
* Customizable widget appearance
* Auto-sync on content changes
* WebSocket real-time chat

== Upgrade Notice ==

= 1.0.0 =
Initial release.
